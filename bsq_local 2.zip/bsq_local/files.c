/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   files.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: labderra <labderra@student.42malaga.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/19 18:45:19 by labderra          #+#    #+#             */
/*   Updated: 2024/03/19 19:06:28 by labderra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_keyb_entry(char *str)
{
	int		fd;
	char	c;

	c = '\0';
	fd = open(str, O_WRONLY | O_CREAT, 777);
	if (fd == -1)
		ft_error("Error\n");
	while (c != 4)
	{
		read(0, &c, 1);
		write(fd, &c, 1);
	}
	close(fd);
}

int	ft_file_size(char *str, int *n_lines)
{
	char	c;
	int		s;
	int		i;
	int		fd;

	fd = open(str, O_RDONLY);
	if (fd == -1)
		ft_error("Error\n");
	s = 1;
	*n_lines = 0;
	i = 0;
	while (s > 0)
	{
		s = read(fd, &c, 1);
		if (c == '\n')
			*n_lines = *n_lines + 1;
		i++;
	}
	close(fd);
	return (i);
}

int	ft_file_load(char *str, char *map)
{
	int	fd;
	int	s;
	int	n_lines;

	fd = open(str, O_RDONLY);
	if (fd == -1)
		ft_error("Error\n");
	s = read(fd, map, ft_file_size(str, &n_lines));
	close(fd);
	return (s);
}
