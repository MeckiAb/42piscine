/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: labderra <labderra@student.42malaga.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/18 12:04:10 by labderra          #+#    #+#             */
/*   Updated: 2024/03/19 19:10:14 by labderra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	main(int argc, char **argv)
{
	int		i;
	struct s_map	map;

	if (argc == 1)
	{
		argc = 2;
		ft_keyb_entry("keyb_map.txt");
		write(1, "keyb_map.txt", 13);
		ft_map("keyb_map.txt");
	}
	else
	{
		i = 1;
		while (i < argc)
		{
			map = ft_map(argv[i]);
			if (map.board != NULL)
				write(1, map.board, ft_strlen(map.board));
			i++;
		}
	}
	return (0);
}
