/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: labderra <labderra@student.42malaga.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/20 13:26:39 by labderra          #+#    #+#             */
/*   Updated: 2024/03/20 13:26:50 by labderra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int             ft_sq_value(struct s_map map, int i)

struct s_map    ft_solve(struct s_map map)
{
    int i;
    int len;
    int pos_max;
    int val_max;

    i = 0;
    len = ft_strlen(map.board)
    while (i < len)
    {
        if (ft_sq_value(map, i) > val_max)
        {
            val_max = ft_sq_value(map, i);
            pos_max = i;
        }
        i++;
    }
    //funcion que pinta las casillas full en el mapa
    return (map);
}
